GENERATE_CODE_PROMPT = """
Generate a Python function that solves the given problem. Ensure the function name matches the entry point provided. Include necessary imports and write clean, efficient code.

Problem: {problem}
Entry point: {entry_point}

Generate the solution below:
"""

FIX_CODE_PROMPT = """
The provided code solution failed the test cases. Please analyze the error and fix the code. Ensure the function name remains the same and the solution addresses the original problem.

Original problem: {input}

Provide the corrected code below:
"""