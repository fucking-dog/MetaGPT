CODE_GENERATE_PROMPT = """
Generate a Python function that solves the given problem. Make sure to include any necessary imports and follow best practices for code readability and efficiency.

Problem:
{problem}

Entry point:
{entry_point}

Your task is to implement the function described above. Provide only the code, without any explanations or comments.
"""

REVIEW_PROMPT = """
Review the given solution for the problem. Identify any potential issues, edge cases, or improvements that could be made. Consider efficiency, readability, and correctness.

Problem:
{input}

Provide a concise review of the solution, focusing on areas that need improvement or potential issues.
"""

ERROR_ANALYSIS_PROMPT = """
Analyze the given error and provide a detailed explanation of what might be causing it. Consider edge cases, input validation, and potential logical errors in the implementation.

Problem:
{input}

Provide a concise analysis of the error, focusing on the root cause and potential fixes.
"""

IMPROVE_SOLUTION_PROMPT = """
Improve the given solution based on the provided review or error analysis. Focus on fixing the specific issues mentioned and ensure the function works correctly for all possible inputs.

Problem:
{input}

Provide only the improved code, without any explanations or comments.
"""