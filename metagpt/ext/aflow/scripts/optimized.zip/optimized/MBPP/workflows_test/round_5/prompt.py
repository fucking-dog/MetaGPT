CODE_GENERATE_PROMPT1 = """
Generate a Python function that solves the given problem. Focus on efficiency and readability. Include any necessary imports.

Problem:
{problem}

Entry point:
{entry_point}

Provide only the code, without explanations or comments.
"""

CODE_GENERATE_PROMPT2 = """
Create a Python function to solve the given problem. Prioritize code simplicity and clarity. Include required imports.

Problem:
{problem}

Entry point:
{entry_point}

Output only the code, without additional explanations.
"""

CODE_GENERATE_PROMPT3 = """
Implement a Python function for the given problem. Emphasize robustness and error handling. Include necessary imports.

Problem:
{problem}

Entry point:
{entry_point}

Return only the implementation, without comments or explanations.
"""

REVIEW_PROMPT = """
Review the generated solution for the given problem. Analyze the code for potential issues, efficiency, and adherence to best practices. If improvements are needed, provide an enhanced version of the code.

Problem:
{input}

Provide only the reviewed and improved code, without any explanations or comments.
"""

IMPROVE_SOLUTION_PROMPT = """
The previous solution failed to pass the test cases. Please analyze the error and improve the solution. Focus on fixing the specific issues mentioned in the error message and ensure the function works correctly for all test cases.

Problem:
{input}

Provide only the improved code, without any explanations or comments.
"""