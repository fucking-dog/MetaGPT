DIVERSE_SOLUTIONS_PROMPT = """
Generate three different Python functions that solve the given problem. Each solution should use a different approach or algorithm. Make sure to include any necessary imports and follow best practices for code readability and efficiency.

Problem:
{input}

Your task is to implement three distinct functions described above. Provide only the code for each solution, without any explanations or comments. Separate each solution with a blank line.
"""

ERROR_ANALYSIS_PROMPT = """
Analyze the given error and provide a detailed explanation of what might be causing it. Consider edge cases, input validation, and potential logical errors in the implementation.

Problem:
{input}

Provide a concise analysis of the error, focusing on the root cause and potential fixes.
"""

IMPROVE_SOLUTION_PROMPT = """
The previous solution failed to pass the test cases. Please improve the solution based on the provided error analysis. Focus on fixing the specific issues mentioned in the error message and ensure the function works correctly for all test cases.

Problem:
{input}

Provide only the improved code, without any explanations or comments.
"""