CODE_GENERATE_PROMPT = """
Generate a Python function that solves the given problem. Make sure to include any necessary imports and follow best practices for code readability and efficiency.

Problem:
{problem}

Entry point:
{entry_point}

Your task is to implement the function described above. Provide only the code, without any explanations or comments.
"""

REVIEW_PROMPT = """
Review and improve the given solution for the following problem. Focus on code correctness, efficiency, and adherence to best practices. If improvements are needed, provide the revised code.

Problem:
{input}

Provide only the improved code or the original code if no improvements are necessary, without any explanations or comments.
"""

IMPROVE_SOLUTION_PROMPT = """
The previous solution failed to pass the test cases. Please analyze the error and improve the solution. Focus on fixing the specific issues mentioned in the error message and ensure the function works correctly for all test cases.

Problem:
{input}

Provide only the improved code, without any explanations or comments.
"""

GENERATE_TEST_CASES_PROMPT = """
Generate a set of test cases for the given problem. Include edge cases and typical scenarios to ensure comprehensive testing of the solution.

Problem:
{input}

Provide only the test cases as Python code, without any explanations or comments.
"""