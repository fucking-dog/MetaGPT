from typing import Literal
import metagpt.ext.aflow.scripts.optimized.MBPP.workflows.template.operator as operator
import metagpt.ext.aflow.scripts.optimized.MBPP.workflows.round_20.prompt as prompt_custom
from metagpt.provider.llm_provider_registry import create_llm_instance
from metagpt.utils.cost_manager import CostManager

DatasetType = Literal["HumanEval", "MBPP", "GSM8K", "MATH", "HotpotQA", "DROP"]

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.llm.cost_manager = CostManager()
        self.custom = operator.Custom(self.llm)
        self.custom_code_generate = operator.CustomCodeGenerate(self.llm)

    async def __call__(self, problem: str, entry_point: str):
        function_name_input = f"Problem: {problem}\nEntry Point: {entry_point}"
        function_name_result = await self.custom(input=function_name_input, instruction=prompt_custom.EXTRACT_FUNCTION_NAME_PROMPT)
        required_function_name = function_name_result['response']

        # Generate test cases
        test_cases_input = f"Problem: {problem}\nEntry Point: {entry_point}\nFunction Name: {required_function_name}"
        test_cases_result = await self.custom(input=test_cases_input, instruction=prompt_custom.GENERATE_TEST_CASES_PROMPT)
        test_cases = test_cases_result['response']

        # Check for edge cases
        edge_cases_input = f"Problem: {problem}\nEntry Point: {entry_point}\nFunction Name: {required_function_name}\nTest Cases: {test_cases}"
        edge_cases_result = await self.custom(input=edge_cases_input, instruction=prompt_custom.EDGE_CASES_PROMPT)
        edge_cases = edge_cases_result['response']

        # Generate multiple solutions
        solutions = []
        for i in range(3):
            solution = await self.custom_code_generate(problem=problem, entry_point=entry_point, instruction=f"Use the function name: {required_function_name}\nTest cases:\n{test_cases}\nEdge cases:\n{edge_cases}")
            solutions.append(solution['response'])

        # Score and select the best solution
        score_input = f"Problem: {problem}\nEntry Point: {entry_point}\nTest Cases:\n{test_cases}\nEdge Cases:\n{edge_cases}\nSolutions:\n" + "\n".join(solutions)
        score_result = await self.custom(input=score_input, instruction=prompt_custom.SCORE_SOLUTIONS_PROMPT)
        best_solution = score_result['response']

        review_input = f"Problem: {problem}\nEntry Point: {entry_point}\nTest Cases:\n{test_cases}\nEdge Cases:\n{edge_cases}\nGenerated Solution:\n{best_solution}"
        review_result = await self.custom(input=review_input, instruction=prompt_custom.REVIEW_PROMPT)
        
        improved_solution = review_result['response'] if review_result['response'] else best_solution
        
        loop_check_input = f"Problem: {problem}\nEntry Point: {entry_point}\nTest Cases:\n{test_cases}\nEdge Cases:\n{edge_cases}\nImproved Solution:\n{improved_solution}"
        loop_check_result = await self.custom(input=loop_check_input, instruction=prompt_custom.INFINITE_LOOP_CHECK_PROMPT)
        
        loop_fixed_solution = loop_check_result['response'] if loop_check_result['response'] else improved_solution
        
        validate_input = f"Problem: {problem}\nEntry Point: {entry_point}\nRequired Function Name: {required_function_name}\nTest Cases:\n{test_cases}\nEdge Cases:\n{edge_cases}\nFinal Solution:\n{loop_fixed_solution}"
        validate_result = await self.custom(input=validate_input, instruction=prompt_custom.VALIDATE_FUNCTION_NAME_PROMPT)
        
        final_solution = validate_result['response'] if validate_result['response'] else loop_fixed_solution
        
        return final_solution, self.llm.cost_manager.total_cost
