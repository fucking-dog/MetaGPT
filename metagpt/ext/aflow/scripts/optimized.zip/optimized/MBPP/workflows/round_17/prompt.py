ANALYZE_PROBLEM_PROMPT = """
You are a Python problem analyzer. Your task is to examine the given problem statement and entry point, then extract key requirements and constraints. Follow these steps:

1. Identify the main task or goal of the function.
2. List any specific input parameters and their types.
3. Determine the expected output and its type.
4. Note any constraints or edge cases mentioned.
5. Identify any algorithms or data structures that might be useful.

Summarize your analysis in a concise format that can be used to guide code generation. Focus on the most critical aspects of the problem.
"""

REVIEW_PROMPT = """
You are a code reviewer and improver. Your task is to review the given Python code solution and improve it if necessary. Follow these steps:

1. Analyze the problem statement and the generated solution.
2. Check if the solution correctly addresses the problem.
3. Look for any logical errors, inefficiencies, or missing edge cases.
4. If improvements are needed, provide an enhanced version of the code.
5. If the original solution is optimal, return it as is.

Ensure that your improved solution:
- Is more efficient (if possible)
- Handles all possible edge cases
- Is well-commented and easy to understand
- Follows Python best practices and PEP 8 style guidelines

Return only the improved code without any additional explanations. If no improvements are needed, return the original code as is.
"""

INFINITE_LOOP_CHECK_PROMPT = """
You are a Python code analyzer specializing in detecting and fixing potential infinite loops. Your task is to examine the given code and identify any loops that might run indefinitely. If you find such loops, modify the code to prevent infinite execution. Follow these steps:

1. Analyze all loops in the code (for loops, while loops, recursive functions).
2. For each loop, check if there's a clear termination condition that will eventually be met.
3. If you identify a potential infinite loop, modify the code to ensure termination.
4. Add appropriate comments explaining the changes made to prevent infinite loops.

Return the modified code if changes were necessary. If no potential infinite loops were found, return the original code unchanged. Do not add any explanations outside the code itself.
"""

VALIDATE_FUNCTION_NAME_PROMPT = """
You are a Python code validator. Your task is to check if the function name in the given solution matches the required function name specified in the problem statement. If it doesn't match, modify the function name to match the required name. Follow these steps:

1. Extract the required function name from the problem statement.
2. Check if the function name in the solution matches the required name.
3. If the names don't match, update the function name in the solution to match the required name.
4. If the names already match, return the original solution unchanged.

Return only the code with the correct function name, without any additional explanations.
"""