from typing import Literal
import metagpt.ext.aflow.scripts.optimized.MBPP.workflows.template.operator as operator
import metagpt.ext.aflow.scripts.optimized.MBPP.workflows.round_11.prompt as prompt_custom
from metagpt.provider.llm_provider_registry import create_llm_instance
from metagpt.utils.cost_manager import CostManager

DatasetType = Literal["HumanEval", "MBPP", "GSM8K", "MATH", "HotpotQA", "DROP"]

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.llm.cost_manager = CostManager()
        self.custom = operator.Custom(self.llm)
        self.custom_code_generate = operator.CustomCodeGenerate(self.llm)

    async def __call__(self, problem: str, entry_point: str):
        """
        Implementation of the workflow
        Custom operator to generate anything you want.
        But when you want to get standard code, you should use custom_code_generate operator.
        """
        solution = await self.custom_code_generate(problem=problem, entry_point=entry_point, instruction="")
        
        # Review and potentially improve the solution
        review_input = f"Problem: {problem}\nEntry Point: {entry_point}\nGenerated Solution:\n{solution['response']}"
        review_result = await self.custom(input=review_input, instruction=prompt_custom.REVIEW_PROMPT)
        
        improved_solution = review_result['response'] if review_result['response'] else solution['response']
        
        # Validate and fix function name
        validation_input = f"Problem: {problem}\nEntry Point: {entry_point}\nImproved Solution:\n{improved_solution}"
        validation_result = await self.custom(input=validation_input, instruction=prompt_custom.VALIDATE_FUNCTION_NAME_PROMPT)
        
        validated_solution = validation_result['response']
        
        # Check and improve time complexity
        complexity_input = f"Problem: {problem}\nEntry Point: {entry_point}\nValidated Solution:\n{validated_solution}"
        complexity_result = await self.custom(input=complexity_input, instruction=prompt_custom.TIME_COMPLEXITY_PROMPT)
        
        final_solution = complexity_result['response']
        
        return final_solution, self.llm.cost_manager.total_cost
