REVIEW_PROMPT = """
You are an expert code reviewer. Review the given solution for the problem and improve it if necessary. Consider the following:

1. Correctness: Does the solution solve the problem accurately?
2. Efficiency: Can the solution be optimized?
3. Readability: Is the code clear and well-commented?
4. Edge cases: Does the solution handle all possible inputs?

If improvements are needed, provide the corrected code. If the solution is already optimal, return the original code.

Problem: {input}

Provide your review and the final, improved code (if applicable) below:
"""