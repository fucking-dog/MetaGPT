from typing import Literal
import metagpt.ext.aflow.scripts.optimized.MBPP.workflows.template.operator as operator
import metagpt.ext.aflow.scripts.optimized.MBPP.workflows.round_17.prompt as prompt_custom
from metagpt.provider.llm_provider_registry import create_llm_instance
from metagpt.utils.cost_manager import CostManager

DatasetType = Literal["HumanEval", "MBPP", "GSM8K", "MATH", "HotpotQA", "DROP"]

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.llm.cost_manager = CostManager()
        self.custom = operator.Custom(self.llm)
        self.custom_code_generate = operator.CustomCodeGenerate(self.llm)

    async def __call__(self, problem: str, entry_point: str):
        # Analyze problem and extract key requirements
        analysis_input = f"Problem: {problem}\nEntry Point: {entry_point}"
        analysis_result = await self.custom(input=analysis_input, instruction=prompt_custom.ANALYZE_PROBLEM_PROMPT)
        
        # Generate initial solution with analysis results
        solution = await self.custom_code_generate(problem=problem, entry_point=entry_point, instruction=analysis_result['response'])
        
        # Review and potentially improve the solution
        review_input = f"Problem: {problem}\nEntry Point: {entry_point}\nGenerated Solution:\n{solution['response']}"
        review_result = await self.custom(input=review_input, instruction=prompt_custom.REVIEW_PROMPT)
        
        improved_solution = review_result['response'] if review_result['response'] else solution['response']
        
        # Check and fix potential infinite loops
        loop_check_input = f"Problem: {problem}\nEntry Point: {entry_point}\nImproved Solution:\n{improved_solution}"
        loop_check_result = await self.custom(input=loop_check_input, instruction=prompt_custom.INFINITE_LOOP_CHECK_PROMPT)
        
        loop_fixed_solution = loop_check_result['response'] if loop_check_result['response'] else improved_solution
        
        # Validate and fix function name
        validate_input = f"Problem: {problem}\nEntry Point: {entry_point}\nLoop-Fixed Solution:\n{loop_fixed_solution}"
        validate_result = await self.custom(input=validate_input, instruction=prompt_custom.VALIDATE_FUNCTION_NAME_PROMPT)
        
        final_solution = validate_result['response'] if validate_result['response'] else loop_fixed_solution
        
        return final_solution, self.llm.cost_manager.total_cost
